/*
 * Implementation is in SpiFirmata.h
 */
