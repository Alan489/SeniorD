/*
 * Implementation is in DhtFirmata.h
 */
