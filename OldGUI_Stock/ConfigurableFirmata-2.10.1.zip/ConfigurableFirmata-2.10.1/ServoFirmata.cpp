/*
 * Implementation is in ServoFirmata.h to avoid having to include Servo.h in all
 * sketch files that include ConfigurableFirmata.h
 */
